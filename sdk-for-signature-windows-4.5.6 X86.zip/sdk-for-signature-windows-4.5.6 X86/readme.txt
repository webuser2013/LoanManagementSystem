
Wacom Ink SDK for signature - Windows

Version 4.5.6

----------------------------------------------------------------------------------------------------------------
About

Wacom Ink SDK for signature - Windows provides the documentation and tools to create signature enabled 
applications using STU and Wintab devices.

For further details on using the SDK see https://developer-docs.wacom.com
Navigate to: Wacom Ink SDK for signature
References are included to the SDK sample code on GitHub

----------------------------------------------------------------------------------------------------------------
File Contents

documentation\
  SignatureSDK-Components-API.pdf
  SignatureSDK-Java API.pdf

SignatureSDK\
  Wacom-Signature-SDK-x86-4.5.5.msi      - Installs 32-bit components on 32-bit or 64-bit Windows
  Wacom-Signature-SDK-x64-4.5.5.msi      - Installs 64-bit components on 64-bit Windows

SigCaptX\
  Wacom-SigCaptX-1.23.2.exe.txt           - SigCaptX 32-bit installer is temporarily removed pending finalisation of a new EULA
  Wacom-Signature-SDK-SigCaptX-1.23.2.msi - Combined 32-bit Signature SDK and SigCaptX installer
     
----------------------------------------------------------------------------------------------------------------
Version History

Signature SDK:

  Release 4.5.6  28-May-2020
    - Rebuilt Zip file

  Release 4.5.5  15-Nov-2019
    - Fix for WizCtl not reporting pad disconnection
    - Fix for Java exception caused by non-matching signer information
    - Ref. SIGSDK-419 + 420

  Release 4.5.4  07-Nov-2019
    - Fix for wizard apparently freezing between screens on STU 530
    - Fix for "hang" on WizCtl close down
    - Ref. SIGSDK-417 + 418

  Release 4.5.2  30-Sep-2019
    - Fix for Hash string display format issue
    - Move JAR to same installer component as DLL to avoid mismatch

  Release v4.5.1a  31-Oct-2019
    - Updated documentation formatting, added API setProperty values
	
  Release v4.5.1 27-Jun-2019
    - Fix for Java RenderBitMap background colour issue
	
  Release v4.5.0 27-Jun-2019
    - Language strings provided for Greek
	- Fix for AddObject parameter problem with the AxWiZCtl
	- Handle licence expiry dates after 19/01/2038
	
  Release v4.4.0.192 20-May-2019
    - Bug fix for integrity test with eval license and invalid signed data

  Release v4.4.0.191 14-May-2019
    - Bug fix for integrity test with eval license and invalid signed data

  Release v4.4.0 03-May-2019
    - Fixed Java support for ISO and Encryption
    - Fixed integrity test with eval license and invalid signed data
    - Fixed image uploader utility
    - ref: SIGSDK-350 359 360 361 364 

  Release v4.3.1 29-Mar-2019
    - Revised detection of the monitor used for wintab signature capture

  Release v4.2.1 21-Feb-2019
    - Support for encrypted import/export of ISO data
    - Added encryption test

  Release v4.2.0   19-Feb-2019
    - Minimum Java version changed from 1.3 to 1.5
    - Check introduced for mismatched flsx.jar/flsx.dll pairing
    - Updated included version of OpenSSL to 1.1
    - Projects migrated to Visual Studio 2017
		
  Release v4.0.1   22-Oct-2018
    - Rebuild .net interop files

  Release v4.0.0   18-Oct-2018
    - Added ISO and Encryption functionality - license dependent
    - Updated icon used in the signature capture window

  Release v3.21.1  27-Sep-2018
    - low pressure strokes rendered darker to avoid apparent loss 

  Release v3.21.0  10-Sep-2018
    - enforces use of a Signature SDK license
    - fixed licensing for Wizard + serial STU-430V
    - fixed CaptureInkColor property in Wizard for STU-540

  Release v3.20.4  26-Mar-2018
    - LMS licensing added

  Release v3.20.3  16-Feb-2018
    - fixed error in 64-bit build for calculating SHA-384 and SHA-512 hashes

  Release v3.20.2  13-Feb-2018
    - fixed BtnsInside simulated button processing

  Release v3.20.1  08-Feb-2018
    - improved RTS pen data
    - revised licensing component - an expired license reverts to evaluation mode

  Release v3.20.0  02-Feb-2018
    - add support for Realtime Stylus (RTS) via Microsoft Ink

  Release v3.19.2  17-Jan-2018
    - fix for STU-541 in Wizard Control

  Release v3.19.0  11-Jan-2018
    - revised directories for installation.
    - Now uses CommonFiles\WacomGSS - can affect existing installations e.g. Java paths
    - improvements to wizard control stability
    - added support for JWT licenses

  Release v3.18.0  03-Oct-2017
    - fix Checkbox FireClick in Wizard control
    - add support for Wizard AddObject base64-endoded image           

  Release v3.17.0  29-Sept-2017
    - delay-loads OpenSSL DLLs
    - fixes issues in wizard associated with double-tap on a button which terminates the wizard
    - includes mitigation for signature mode tapping OK when no ink has been captured

  Release v3.16.0  29-June-2017
    - fixed licence check


Signature SDK SigCaptX:

   Release v1.23.2  23-Aug-2019
    Rebuild Mozilla NSS tools with current source to counteract false positives in some AV engines
    
  Release v1.23.1  28-Jun-2019
    Fixed for "flashing" window issue in wizard
    Exception catch added to prevent network error
		
  Release v1.23.0  19-Feb-2019
    OpenSSL v1.1
    Change to how server process is started
    Fix to ReadEncodedBitmap for HTTP URLs
		
  Release v1.21.2  25-Oct-2018
    Includes revised Signature SDK v4.0
    Fix for SigCaptX server startup in Edge

  Release v1.21.0  26-Sept-2018
    Includes revised Signature SDK v3.21 which enforces the use of a license
    Enhancements for Citrix environment
    Revised internal build system

  Release v1.18.1  27-Mar-2018
    Further changes to support newer versions of Firefox with new certificate database

  Release v1.18.0  20-Feb-2018
    Fix for revised Firefox certificate database

  Release v1.17.0  18-Jan-2018
    Updated to Signature SDK v3.19.2

  Release v1.16.0  03-Oct-2017
    fix AddPrimitive line and rectangle 

  Release v1.15.0  29-Sept-2017
    fixes issues in wizard associated with double-tap on a button which terminates the wizard
    fixes incorrect rejection of negative dimension values in SigObj.RenderBitmap

  Release v1.14.0  06-July-2017
    Added support for STU-540/541 via inclusion of updated Signature SDK
    Includes some additional logging
    Installer enables localhost loopback for Edge on Win 10 (so it is no longer necessary for the user to run CheckNetIsolation)

  Release v1.13.3  27-Jan-2017
    The STU Driver is now included in the SigCaptX (EXE) installer


    
Copyright � 2020 Wacom, Co., Ltd. All Rights Reserved.
